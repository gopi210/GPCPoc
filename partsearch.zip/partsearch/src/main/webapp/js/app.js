var app = angular.module('partSearch',['bootstrap.fileField'])

app.controller('partSearchCtrl',

  function MyController($scope, $http) {

    //the image
    $scope.previewImage;

    $scope.uploadImage = function() {
      var fd = new FormData();
      var imgBlob = dataURItoBlob($scope.previewImage);
      fd.append('file', imgBlob);
      var imageData = {
    		  "image":$scope.previewImage.split(',')[1],
    		  "productType": "test"
      }
      $http.post(
          'http://10.0.0.125:8081/partsearch/uploadImage',
          imageData, {
            headers: {
              'Content-Type': 'application/json',
              'Access-Control-Request-Method': 'POST,GET'
            }
          }
        )
        .success(function(response) {
        	  //$scope.test=angular.toJson(response);
          console.log('success', response.success);
          $scope.concepts = [];
          angular.forEach(response.parts, function(value, key) {
              $scope.concepts.push(value);
          });
        })
        .error(function(response) {
          console.log('error', response);
        });
    }


    //you need this function to convert the dataURI
    function dataURItoBlob(dataURI) {
      var binary = atob(dataURI.split(',')[1]);
      var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
      var array = [];
      for (var i = 0; i < binary.length; i++) {
        array.push(binary.charCodeAt(i));
      }
      return new Blob([new Uint8Array(array)], {
        type: mimeString
      });
    }

  });


//your directive
app.directive("fileread", [
  function() {
    return {
      scope: {
        fileread: "="
      },
      link: function(scope, element, attributes) {
        element.bind("change", function(changeEvent) {
          var reader = new FileReader();
          reader.onload = function(loadEvent) {
            scope.$apply(function() {
              scope.fileread = loadEvent.target.result;
            });
          }
          reader.readAsDataURL(changeEvent.target.files[0]);
        });
      }
    }
  }
]);

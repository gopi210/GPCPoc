 
package com.aiexplore.partspoc;
 
import com.fasterxml.jackson.databind.ObjectMapper;
 
public class JSON2JAVAConvertor {
      
       public static String convert2JSON(Object obj)
       {
              try
              {
                
              ObjectMapper mapper = new ObjectMapper();
              return mapper.writeValueAsString(obj);
              }catch(Exception e)
              {
                     e.printStackTrace();
                     return null;
              }
       }
 
       public static <T> T convertoJavaObj(String jsoncontent,Class<T> valueType)
       {
              try
              {
                 ObjectMapper mapper = new ObjectMapper();
                 return mapper.readValue(jsoncontent, valueType);
              }catch(Exception e)
              {
                     e.printStackTrace();
              }
              return null;
       }
      
}
 
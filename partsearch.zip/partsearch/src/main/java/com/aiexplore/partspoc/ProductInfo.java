package com.aiexplore.partspoc;

public class ProductInfo {
	private String partNum;
	private String imageName;
	private String imageURL;
	public String getImageURL() {
		return imageURL;
	}
	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}
	public float getCount() {
		return count;
	}
	public void setCount(float count) {
		this.count = count;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	private float count;
	private String location;
	private String desc;
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	public String getPartNum() {
		return partNum;
	}
	public void setPartNum(String partNum) {
		this.partNum = partNum;
	}
	public String getLineAbbrev() {
		return lineAbbrev;
	}
	public void setLineAbbrev(String lineAbbrev) {
		this.lineAbbrev = lineAbbrev;
	}
	public Double getPrediction() {
		return prediction;
	}
	public void setPrediction(Double double1) {
		this.prediction = (double) double1;
	}
	private String lineAbbrev;
	private Double prediction;

}

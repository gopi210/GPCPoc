package com.aiexplore.partspoc;

public class PartPredictReq {
private byte[] image;


public byte[] getImage() {
	return image;
}
public void setImage(byte[] image) {
	this.image = image;
}
public String getProductType() {
	return ProductType;
}
public void setProductType(String productType) {
	ProductType = productType;
}
private String ProductType;
}

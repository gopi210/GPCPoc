package com.aiexplore.partspoc;

import java.util.List;

public class PredictResponse {
private boolean isSuccess;
public boolean isSuccess() {
	return isSuccess;
}
public void setSuccess(boolean isSuccess) {
	this.isSuccess = isSuccess;
}

private List<ProductInfo> Parts;
public List<ProductInfo> getParts() {
	return Parts;
}
public void setParts(List<ProductInfo> parts) {
	Parts = parts;
}


}

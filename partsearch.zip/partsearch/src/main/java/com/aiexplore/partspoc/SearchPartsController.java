package com.aiexplore.partspoc;

import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
@RestController
@RequestMapping("/uploadImage")
@EnableWebMvc
public class SearchPartsController {
	    @Autowired
	    VisionApi va;
	    
	    private static String UPLOADED_FOLDER = "/tmp/";
	    @RequestMapping(method=RequestMethod.POST,produces="application/json")
		/*public @ResponseBody PredictResponse getPerson(@RequestParam("file") MultipartFile file,
                RedirectAttributes redirectAttributes){*/
	    public @ResponseBody PredictResponse getPerson(@RequestBody PartPredictReq input){
	    	/*if (file.isEmpty()) {
	            redirectAttributes.addFlashAttribute("message", "Please select a file to upload");
	            response.setSuccess(false);
	            return response;
	        }*/
	     	List<ProductInfo> Parts=new ArrayList<ProductInfo>();
		    ProductInfo Part= new ProductInfo();
		    PredictResponse response = new PredictResponse();
	        try {
                System.out.println("RequestData"+input.toString());
	            // Get the file and save it somewhere
	            /*byte[] bytes = file.getBytes();*/
                System.out.println("requestdata"+input.getImage());
	         	byte[] bytes = input.getImage();
	         	
	            VisionAPIResponse prediction= va.getPartPrediction(bytes);
	            if(prediction!=null) {
	            	 for (int j = 0; j < prediction.getPredictions().size(); j++) {
	            		 if(prediction.getPredictions().get(j).getProbability()>=0.6) {
	            			 
	            			 Part.setPartNum(prediction.getPredictions().get(j).getTag().split("-")[1]);	 
	            			 Part.setLineAbbrev(prediction.getPredictions().get(j).getTag().split("-")[0]);
	            			 Part.setPrediction(prediction.getPredictions().get(j).getProbability());
	            			 Part.setImageName(prediction.getPredictions().get(j).getTag()+".jpg");
	            			 Parts.add(Part);
	            		 }
	            		 response.setParts(Parts);
			    	   }
	            	
	            }
	            System.out.println("MS output"+prediction);
	            /*out=cf.searchImage(bytes);
	            outList.add(out);*/

	            /*System.out.println("MS output"+msout);*/
	            /*redirectAttributes.addFlashAttribute("message",
	                        "You successfully uploaded '" + file.getOriginalFilename() + "'");*/

	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        
	        //for(String result : results) {
				
				//System.out.println(result);
			//}
            response.setSuccess(true);
            System.out.println("respone sent"+response);
	        return response;
		}
	
}

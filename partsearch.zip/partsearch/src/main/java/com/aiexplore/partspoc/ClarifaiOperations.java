package com.aiexplore.partspoc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.jasper.tagplugins.jstl.core.Out;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.google.gson.JsonObject;

import clarifai2.api.ClarifaiBuilder;
import clarifai2.api.ClarifaiClient;
import clarifai2.api.ClarifaiResponse;
import clarifai2.api.request.input.SearchClause;
import clarifai2.api.request.input.SearchInputsRequest;
import clarifai2.api.request.model.*;
import clarifai2.dto.input.ClarifaiInput;
import clarifai2.dto.input.ClarifaiInputValue;
import clarifai2.dto.input.ClarifaiURLImage;
import clarifai2.dto.input.SearchHit;
import clarifai2.dto.model.Model;
import clarifai2.dto.model.output.ClarifaiOutput;
import clarifai2.dto.model.output_info.ConceptOutputInfo;
import clarifai2.dto.prediction.Concept;
import clarifai2.dto.prediction.Prediction;
import clarifai2.dto.search.SearchInputsResult;
import clarifai2.dto.input.ClarifaiImage;
import com.aiexplore.partspoc.ProductInfo;

public class ClarifaiOperations {
	final ClarifaiClient client = new ClarifaiBuilder("d4073c5bb8e94bb5b923f94d14159441").buildSync();
	final String csvFile = "/Users/hadoop/Desktop/Technical/LatestPartsInfo.csv";
    BufferedReader br = null;
    String line = "";
    String cvsSplitBy = ",";
    
	Output out = new Output();
	public void addImageToModel(String folderToRead) throws IOException {
		File folder = new File(folderToRead);
		File[] listOfFiles = folder.listFiles();
		String parentDirName="";
        HashMap hs = new HashMap();
		    for (int i = 0; i < listOfFiles.length; i++) {
		      if (listOfFiles[i].isFile()) {
		        /*System.out.println("File " + listOfFiles[i].getName());*/
		        String path = listOfFiles[i].getParent(); 
		        parentDirName=path.substring(path.lastIndexOf("/")+1,path.length());
		        /*System.out.println(parentDirName);*/
		        String filePath = folderToRead+listOfFiles[i].getName();
		        Path fileLocation = Paths.get(filePath);
		        byte[] imageRaw= Files.readAllBytes(fileLocation);
		        List<ClarifaiInput> imgList=client.addInputs()
		        .plus(
		            ClarifaiInput.forImage(imageRaw)
		                .withConcepts(Concept.forID(parentDirName))
		        )
		        .executeSync().get();
		        
		       if(imgList!=null && imgList.size()>0) {
		    	   for (int j = 0; j < imgList.size(); j++) {
		    		  System.out.println("ImageID"+":"+listOfFiles[i].getName()+"ClarifaiID:"+imgList.get(j).id());
		    		  hs.put(imgList.get(j).id(), listOfFiles[i].getName()) ;
		    	   }
		       }
		        
		      } else if (listOfFiles[i].isDirectory()) {
		        System.out.println("Directory " + listOfFiles[i].getName());
		      }
		    }
		    /*client.createModel("first")
	        .withOutputInfo(ConceptOutputInfo.forConcepts(
	            Concept.forID(parentDirName)
	        ))
	        .executeSync();*/
	        /*client.trainModel("first").executeSync();
	        System.out.println("Model Trained Successfully");*/
	}
	public Output searchImage(byte[] imagedata) throws IOException {
		   List<ProductInfo> plist = new ArrayList<ProductInfo>();
		   List<SearchHit> rs= client.searchInputs(SearchClause.matchImageVisually(ClarifaiImage.of(imagedata)))
			    .getPage(1)
			    .executeSync().getOrNull().searchHits();
		   ClarifaiInputValue sc=rs.get(1).input().inputValue();
		   System.out.println("Sc Value:"+sc.toString());
		   /*List<SearchHit> rs1=client.searchInputs(SearchClause.matchConcept(Concept.forID("autofilters"))).
				   getPage(1).executeSync().getOrNull().searchHits();
		   System.out.println("FiltersSize"+rs1.size());*/
		   /*List<SearchHit> rs=client.searchInputs(SearchClause.matchConcept(Concept.forName("batteries"))).
				   and(SearchClause.matchImageVisually(ClarifaiImage.of(imagedata)))
		    .getPage(1)
		    .executeSync().getOrNull().searchHits();*/
		    
		   System.out.println("Concept data"+rs.size());
		   /*System.out.println("Search result multi query"+rs1.toString());*/
		   /*List<SearchHit> rs=client.searchInputs()
		    .ands(
		    		SearchClause.matchUserTaggedConcept(Concept.forName("autofilters")),
		    		SearchClause.matchImageVisually(ClarifaiImage.of(imagedata))
		    )
		    .getPage(1)
		    .executeSync().getOrNull().searchHits();
		   System.out.println(rs.size());*/
		   if(rs != null && rs.size() > 0) {
				for (int j = 0; j < rs.size(); j++) {
					float s= rs.get(j).score();
					System.out.println(s);
                    if(s > 0.5) {
                    	System.out.println("Search result"+j+"Score:"+s+rs.get(j).input().id());
                    	ProductInfo p=getPartsInfo(rs.get(j).input().id(),s);
                    	System.out.println("****Part Num"+p.getPartNum());
                    	p.getPartNum();
                    if(p.getPrediction()>0.5) {
                    	//System.out.println("****Part Num"+plist.get(1).getPartNum());
                    	plist.add(p);
                    }
                    
                    }
				}
			}
		  /*out.setProductType(conceptName);*/
		   out.setResultset(plist);
	    return out;
	}
	private ProductInfo getPartsInfo(String clarifID,float predict) throws IOException {
		ProductInfo p = new ProductInfo();
		br = new BufferedReader(new FileReader(csvFile));
		while ((line = br.readLine()) != null) {

            // use comma as separator
            String[] fields = line.split(cvsSplitBy);
               if(fields[1].equals(clarifID)) {
            	   String image=fields[0];
            	   String[] partNum=fields[0].split("_");
            	   p.setLineAbbrev(partNum[0]);
            	   p.setPartNum(partNum[1].replaceAll(".jpg", ""));
            	   p.setPrediction((double)predict);
            	   p.setImageName("https://s3.amazonaws.com/clarifai-api/img2/prod/small/cac1a0812f38454f9f3670424badd8ea/"+clarifID);
            	   p.setCount(4);
            	   if(partNum[0]=="FIL") {
            		   p.setDesc("filters");
            	   }
            	   if(partNum[0]=="BAT") {
            		   p.setDesc("batteries");
            	   }
            	   if(partNum[0]=="CTH") {
            		   p.setDesc("bearings");
            	   }
            	   p.setLocation("1040 Cobb Pkwy,Atlanta,GA-30339");
               }

            System.out.println("Country [code= " + fields[0] + " , name=" + fields[1] + "]");

        }
		return p;
	}
	
	public List<Output> predictImage(byte[] imagedata) throws IOException {
		String Response="";
		List<Output> outResult=new ArrayList<Output>();
		List<String> resultList = new ArrayList<String>();
		//out=searchImage(imagedata,"batteries");
		List<ClarifaiOutput<Concept>> predictionResults=client.getModelByID("autoparts").executeSync().get().asConceptModel().predict().withInputs(
                ClarifaiInput.forImage(imagedata)
                ).executeSync().get();
		if (predictionResults != null && predictionResults.size() > 0) {
			 
			 // Prediction List Iteration
			 for (int i = 0; i < predictionResults.size(); i++) {
			 
			 ClarifaiOutput<Concept> clarifaiOutput = predictionResults.get(i);
			 
			 List<Concept> concepts = clarifaiOutput.data();
			 
			 if(concepts != null && concepts.size() > 0) {
			 for (int j = 0; j < concepts.size(); j++) {
			 if(concepts.get(j).value()>0.85) {
				 resultList.add(concepts.get(j).name());
				 System.out.println("Matching Concept Score"+concepts.get(j).value()); 
				 System.out.println("Matching Concept"+concepts.get(j).name());
				 out.setProductType(concepts.get(j).name());
				 out=searchImage(imagedata);
				 outResult.add(out);
			 }
			 }
			 }
			 }
			 }
			 
		
		
		return outResult;
	}
	

}

package com.aiexplore.partspoc;

import java.util.List;

public class Output {
String productType;
public String getProductType() {
	return productType;
}
public void setProductType(String productType) {
	this.productType = productType;
}
public List<ProductInfo> getResultset() {
	return resultset;
}
public void setResultset(List<ProductInfo> resultset) {
	this.resultset = resultset;
}
List<ProductInfo> resultset;
}

package com.aiexplore.partspoc;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLPeerUnverifiedException;
import java.net.URL;
import com.aiexplore.partspoc.VisionAPIResponse;

public class VisionApi {

	final String predictKey = "3a4ce229ff6a4a3590bbd03c3d8e1cf7";

	public VisionAPIResponse getPartPrediction(byte[] imagedata) throws IOException {
		VisionAPIResponse vr = null;
		System.out.println("Received");
		System.out.println("Payload"+imagedata.toString());
		String imgFile="/Users/hadoop/Desktop/Technical/20171107_133240.jpg";
		byte[] imgDataBa = new byte[(int)imgFile.length()];
		DataInputStream dataIs = new DataInputStream(new FileInputStream(imgFile));
		dataIs.readFully(imagedata);
		StringBuffer response = new StringBuffer();
		URL url = new URL(
				"https://southcentralus.api.cognitive.microsoft.com/customvision/v1.0/Prediction/4a273e76-6d51-4276-95ae-5b3a7a977053/image?iterationId=eaed1197-a779-4dc3-9470-25d885f35b64");
		HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();
		httpCon.setDoOutput(true);
		httpCon.setRequestMethod("POST");
		httpCon.setRequestProperty("Prediction-Key", predictKey);
		httpCon.setRequestProperty("Content-Type", "application/octet-stream");
		httpCon.setDoOutput(true);
		OutputStream out=httpCon.getOutputStream();
	    out.write(imagedata);
	    System.out.println("Reached here");
		int responseCode = httpCon.getResponseCode();
		if(responseCode>=200) {
			BufferedReader in = new BufferedReader(
			        new InputStreamReader(httpCon.getInputStream()));
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
		
			in.close();
			
		}
		System.out.println(response.toString());
		
		vr=JSON2JAVAConvertor.convertoJavaObj(response.toString(), VisionAPIResponse.class);
		
		return vr;
	}
}
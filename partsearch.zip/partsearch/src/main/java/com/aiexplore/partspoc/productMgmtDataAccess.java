package com.aiexplore.partspoc;
import com.google.cloud.bigtable.hbase.BigtableConfiguration;

import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
public class productMgmtDataAccess {
	private static final byte[] TABLE_NAME = Bytes.toBytes("product_info");
	  private static final byte[] COLUMN_FAMILY_NAME = Bytes.toBytes("column");
	  private static final byte[] COLUMN_NAME1 = Bytes.toBytes("imageName");
	  private static final byte[] COLUMN_NAME2 = Bytes.toBytes("clarifaiID");
	  private static final String[] GREETINGS =
	      { "Hello World!", "Hello Cloud Bigtable!", "Hello HBase!" };
	  private static final String csvFile = "/Users/hadoop/Desktop/Technical/LatestPartsInfo.csv";
      BufferedReader br = null;
      String line = "";
      String cvsSplitBy = ",";
      

	  private static void doHelloWorld(String projectId, String instanceId) {

	    try (Connection connection = BigtableConfiguration.connect(projectId, instanceId)) {
	    	 BufferedReader br = null;
	     String line = "";
	     String cvsSplitBy = ",";
	    	  br = new BufferedReader(new FileReader(csvFile));
	      Admin admin = connection.getAdmin();

	      HTableDescriptor descriptor = new HTableDescriptor(TableName.valueOf(TABLE_NAME));
	      descriptor.addFamily(new HColumnDescriptor(COLUMN_FAMILY_NAME));

	      print("Create table " + descriptor.getNameAsString());
	      admin.createTable(descriptor);

	      Table table = connection.getTable(TableName.valueOf(TABLE_NAME));

	      print("Write some greetings to the table");
	      while ((line = br.readLine()) != null) {

              // use comma as separator
              String[] fields = line.split(cvsSplitBy);
              String[] prodvValues =
        	      { fields[0], fields[1], fields[2],fields[3] };
              for (int i = 0; i < prodvValues.length; i++) {
      	        String rowKey = "greeting" + i;
                Put put = new Put(Bytes.toBytes(rowKey));
      	        put.addColumn(COLUMN_FAMILY_NAME, COLUMN_NAME1, Bytes.toBytes(prodvValues[i]));
      	        put.addColumn(COLUMN_FAMILY_NAME, COLUMN_NAME2, Bytes.toBytes(prodvValues[i]));
      	        table.put(put);
      	      }

              System.out.println("Country [code= " + fields[0] + " , name=" + fields[1] + "]");

          }

	      br.close();

	      String rowKey = "greeting0";
	      Result getResult = table.get(new Get(Bytes.toBytes(rowKey)));
	      String greeting = Bytes.toString(getResult.getValue(COLUMN_FAMILY_NAME, COLUMN_NAME1));
	      System.out.println("Get a single greeting by row key");
	      System.out.printf("\t%s = %s\n", rowKey, greeting);

	      Scan scan = new Scan();

	      print("Scan for all greetings:");
	      ResultScanner scanner = table.getScanner(scan);
	      for (Result row : scanner) {
	        byte[] valueBytes = row.getValue(COLUMN_FAMILY_NAME, COLUMN_NAME1);
	        System.out.println('\t' + Bytes.toString(valueBytes));
	      }

	      print("Delete the table");
	      /*admin.disableTable(table.getName());*/
	      /*admin.deleteTable(table.getName());*/

	    } catch (IOException e) {
	      System.err.println("Exception while running product Big table: " + e.getMessage());
	      e.printStackTrace();
	      System.exit(1);
	    }

	    System.exit(0);
	  }

	  private static void print(String msg) {
	    System.out.println("HelloWorld: " + msg);
	  }

	  public static void main(String[] args) {
	 

	    doHelloWorld("nodejslab-183223", "firsttestinstance");
	  }

	  /*private static String requiredProperty(String prop) {
	    String value = System.getProperty(prop);
	    if (value == null) {
	      throw new IllegalArgumentException("Missing required system property: " + prop);
	    }
	    return value;
	  }*/

}

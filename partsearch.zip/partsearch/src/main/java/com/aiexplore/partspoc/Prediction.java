package com.aiexplore.partspoc;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"TagId",
"Tag",
"Probability"
})
public class Prediction {

@JsonProperty("TagId")
private String tagId;
@JsonProperty("Tag")
private String tag;
@JsonProperty("Probability")
private Double probability;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("TagId")
public String getTagId() {
return tagId;
}

@JsonProperty("TagId")
public void setTagId(String tagId) {
this.tagId = tagId;
}

@JsonProperty("Tag")
public String getTag() {
return tag;
}

@JsonProperty("Tag")
public void setTag(String tag) {
this.tag = tag;
}

@JsonProperty("Probability")
public Double getProbability() {
return probability;
}

@JsonProperty("Probability")
public void setProbability(Double probability) {
this.probability = probability;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
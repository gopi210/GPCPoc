package com.aiexplore.partspoc;
import java.io.IOException;
import java.util.List;
import com.aiexplore.partspoc.ClarifaiOperations;
public class TestClarifai {

	public static void main(String[] args) throws IOException {
 		// TODO Auto-generated method stub
		ClarifaiOperations cf = new ClarifaiOperations();
		//String FileName="//Users//hadoop//Desktop//Technical//CarParts//cars//CarBattery.jpg";
		//System.out.println(FileName);
		cf.addImageToModel("/Users/hadoop/Desktop/Technical/NapaParts/batteries/");
		//List<String> results=cf.predictImage(FileName);
       // for(String result : results) {
			
			//System.out.println(result);
		//}//

	}

}

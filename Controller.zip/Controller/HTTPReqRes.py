#!/usr/bin/env python
from flask import Flask,jsonify,request
from subprocess import call
import label_image
app = Flask(__name__)
@app.route('/uploadimage',methods=['POST'])
def getPrediction():
    if not request.json or not 'productType' in request.json:
        abort(400)
    prodType = request.json['productType']
    subprocess.call(" python label_image     --graph=/Users/hadoop/Desktop/tensorflow/tensorflow-for-poets-2/tf_files/retrained_graph.pb      --image=/Users/hadoop/Desktop/Technical/20171030_143033.jpg", shell=True)
    print(resdata)
    return jsonify({'prodtype': prodType}), 201
if __name__ == '__main__':
    app.run(port=8081,debug=True)

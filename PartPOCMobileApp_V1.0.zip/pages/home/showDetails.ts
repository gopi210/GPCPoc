import { Component } from '@angular/core';
import { Platform, NavParams, ViewController, LoadingController} from 'ionic-angular';
import { Http, Headers } from '@angular/http';
import {DomSanitizer} from '@angular/platform-browser';
@Component({
  templateUrl: `showDetails.html`
})
export class ShowDetails {
  partInfo;
  curpartDetails: any;
  address:any;
  desc:any;
  qty:any;
  price:any;
  uberexptime:any;
  uberexpprice:any;
  showUberX:boolean;
  showStorePick:boolean;
  showUberStd:boolean;
  miles:any;
  deloptions:any;
  private getPartAvail='http://10.5.221.234:9082/partsearch/getPartsInfo';
  constructor(
    public platform: Platform,
    public params: NavParams,
    public viewCtrl: ViewController,
    private sanitizer:DomSanitizer,
    public http: Http,
    public loadingController:LoadingController,

  ){
  this.partInfo=this.params.get('partAvailDetails');
  let currentPart = {
        "partNum": this.partInfo.partNum,
        "lineAbbrev": this.partInfo.lineAbbrev,
        "lat":this.partInfo.lat,
        "longt":this.partInfo.longt
    };
  let headers = new Headers({ 'Content-Type': 'application/json' });
  let loading = this.loadingController.create({content : "Listing availability and stores near you...please wait"});
  loading.present();
  this.http.post(this.getPartAvail, currentPart, {headers: headers} ).map(res => res.json())
  .subscribe(data => {
    console.log(data);
    this.desc=data["desc"];
    this.address=data["address"];
    this.qty=data["onHand"];
    this.price=data["price"];
    this.uberexptime=data["uberexptime"];
    this.uberexpprice=data["uberexpprice"];
    this.miles=data["miles"];
    loading.dismissAll();
    this.deloptions="uberex";
    this.showUberX=true;
 });
}
radioChecked(delType){
  if(delType=="uberex"){
   this.showUberX=true;
   this.showStorePick=false;
   this.showUberStd=false;
  }
  if(delType=="storpick"){
   this.showStorePick=true;
   this.showUberX=false;
   this.showUberStd=false;
  }
  if(delType=="uberstd"){
   this.showUberStd=true;
   this.showUberX=false;
   this.showStorePick=false;
  }

}
dismiss() {
   this.viewCtrl.dismiss();
 }
 sanitize(url:string){
    return this.sanitizer.bypassSecurityTrustUrl(url);
}
}

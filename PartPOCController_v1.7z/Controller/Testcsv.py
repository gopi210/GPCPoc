import pandas as pd
import geopy.distance
import requests
import json
from operator import itemgetter, attrgetter
distances=[]
lat1 = str(33.9107880)
lon1 = str(-84.4583570)
df = pd.read_csv("StoreAddressByLocation.csv", names=['ADR_LN_1', 'ADR_LN_2', 'CTY_NM', 'CY_NM', 'ST_CD', 'PSTL_CD','CTRY_CD','CTY_TX_PCT','CY_TX_PCT','ST_TX_PCT','TM_ZNE_NUM','LATITUDE','LONGITUDE'])
#data=df[(df['LATITUDE']>lat1)].sort_values('LATITUDE', ascending=False).head(10)
#data=df['LATITUDE'].between(>29,<35 )
#print(data)
df = df[((df['LATITUDE'] >= str(33.7)) & (df['LATITUDE'] <= str(34)))]
data = df[((df['LONGITUDE'] >= str(-84)) & (df['LONGITUDE'] <= str(-85)))].sort_values('LATITUDE', ascending=False).tail(10)
#print(str(df['LATITUDE'])+str(df['LONGITUDE']))
coords_1 = (lat1, lon1)
coords_2 = (33.60069, -83.85991)
for index, row in data.iterrows():
    if(index>0):
        coords_2=(row['LATITUDE'],row['LONGITUDE'])
        address=str(row['LATITUDE'])+' '+str(row['LONGITUDE'])+' '+str(row['ADR_LN_1'])
        miles=geopy.distance.vincenty(coords_1, coords_2).mi
        distances.append({'address':address,'miles':miles})
        #print(row['ADR_LN_1']+row['CTY_NM']+row['ADR_LN_1']+row['ST_CD'])
        #print(distance.append(geopy.distance.vincenty(coords_1, coords_2).mi))
        #sorted(distances, key=lambda distance: distances[0])
        #sorted(distances, key=itemgetter(0))
        #sorted(distances, key=lambda k: k['miles'])
        #sorted(distances, key=itemgetter('miles'))
        #distances.sort(key=operator.itemgetter('miles'))
print(sorted(distances, key=itemgetter('miles')))
partNum="1515"
lineAbbrev="FIL"
partInqReq={
  "CorrelationID":"481bfd23-aa55-4de0-a7da-2f932ab121ee",
  "SourceSystem":"IBS Portal",
  "CustomerNumber":4757,
  "Part":[
    {
      "LineAbbrev":lineAbbrev,
      "PartNumber":partNum
    }
  ],
  "Customer":{
    "CustomerNumber":801,
    "Password":"fac69fe3f2cc0ca115a8362df910de4b4eee0d61"
  }
}
headers = {'content-type': 'application/json'}
URL="http://10.10.10.233:18080/taap/invoicemanagement/partPriceAvailability"
response=requests.post(url = URL, data = json.dumps(partInqReq),headers=headers)
test = response.json()
for doc in test['DetailResponse']['Response']['Responder'][0]['Part']:
    print(doc['Quantity']['OnHand'])
#print(test)
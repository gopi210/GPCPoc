import { Component } from '@angular/core';
import { Platform, NavParams, ViewController} from 'ionic-angular';
import { Http, Headers } from '@angular/http';
import {DomSanitizer} from '@angular/platform-browser';
@Component({
  templateUrl: `showDetails.html`
})
export class ShowDetails {
  partInfo;
  curpartDetails: any;
  private getPartAvail='http://10.0.0.153:8080/partsearch/getPartsInfo';
  constructor(
    public platform: Platform,
    public params: NavParams,
    public viewCtrl: ViewController,
    private sanitizer:DomSanitizer,
    public http: Http
  ){
  this.partInfo=this.params.get('partAvailDetails');
  let currentPart = {
        "partNum": this.partInfo.partNum,
        "lineAbbrev": this.partInfo.lineAbbrev,
        "lat":this.partInfo.lat,
        "longt":this.partInfo.longt
    };
  let headers = new Headers({ 'Content-Type': 'application/json' });
  this.http.post(this.getPartAvail, currentPart, {headers: headers} ).map(res => res.json())
  .subscribe(data => {
    console.log(data);
    this.curpartDetails=data;
 });
}
dismiss() {
   this.viewCtrl.dismiss();
 }
 sanitize(url:string){
    return this.sanitizer.bypassSecurityTrustUrl(url);
}
}

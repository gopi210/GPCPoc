import { Component } from '@angular/core';
import { Camera } from 'ionic-native';
import { Http, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
@Component({
  templateUrl: 'home.html'
})

export class HomePage {
  public base64Image: string;
  partData: any;
  private partsInfoURL='http://192.168.43.206:8080/partsearch/uploadImage';

  constructor(public http: Http) {
  }

  takePicture(){
    Camera.getPicture({
        quality : 75,
        destinationType : Camera.DestinationType.DATA_URL,
        sourceType : Camera.PictureSourceType.CAMERA,
        allowEdit : true,
        encodingType: Camera.EncodingType.JPEG,
        targetWidth: 300,
        targetHeight: 300,
        saveToPhotoAlbum: false
    }).then((imageData) => {
        this.base64Image = "data:image/jpeg;base64," + imageData;
    }, (err) => {
        console.log(err);
    });
  }
  searchPart(){
    let postData = {
          image: this.base64Image.split(',')[1],
          prodType: "test"
      }
    let headers = new Headers({ 'Content-Type': 'application/json' });
    return this.http.post(this.partsInfoURL, postData, {headers: headers} ).map(res => res.json())
    .subscribe(data => {
      console.log(data.outputs[0].resultset);
      this.partData=data.outputs[0].resultset;
   });
  }
}

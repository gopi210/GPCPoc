import { Component } from '@angular/core';
import { Platform, NavParams, ViewController} from 'ionic-angular';
import {DomSanitizer} from '@angular/platform-browser';
@Component({
  templateUrl: `showDetails.html`
})
export class ShowDetails {
  partInfo;
  constructor(
    public platform: Platform,
    public params: NavParams,
    public viewCtrl: ViewController,
    private sanitizer:DomSanitizer
  ){
  this.partInfo=this.params.get('curPart');
}
dismiss() {
   this.viewCtrl.dismiss();
 }
 sanitize(url:string){
    return this.sanitizer.bypassSecurityTrustUrl(url);
}
}

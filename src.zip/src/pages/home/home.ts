import { Component } from '@angular/core';
import { Camera } from 'ionic-native';
import { Http, Headers } from '@angular/http';
import { ModalController } from 'ionic-angular';
import { ShowDetails } from './showDetails';
import 'rxjs/add/operator/map';
@Component({
  templateUrl: 'home.html'
})

export class HomePage {
  public base64Image: string;
  public partDet: any;
  partData: any;
  private partsInfoURL='http://10.0.0.125:8080/partsearch/uploadImage';
  constructor(public http: Http, public modalCtrl: ModalController) {
  }
  takePicture(){
    Camera.getPicture({
        quality : 100,
        destinationType : Camera.DestinationType.DATA_URL,
        sourceType : Camera.PictureSourceType.CAMERA,
        allowEdit : true,
        encodingType: Camera.EncodingType.JPEG,
        saveToPhotoAlbum: false
    }).then((imageData) => {
        this.base64Image = "data:image/jpeg;base64," + imageData;
    }, (err) => {
        console.log(err);
    });
  }
  SelectPicture(){
    Camera.getPicture({
        quality : 75,
        destinationType : Camera.DestinationType.DATA_URL,
        sourceType : Camera.PictureSourceType.PHOTOLIBRARY,
        allowEdit : true,
        encodingType: Camera.EncodingType.JPEG,
        targetWidth: 224,
        targetHeight: 224,
        saveToPhotoAlbum: false
    }).then((imageData) => {
        this.base64Image = "data:image/jpeg;base64," + imageData;
    }, (err) => {
        console.log(err);
    });
  }
  productTypes(): string[] {
    return [
      "Filters",
      "Batteries",
      "Bearings"
    ];
  }
  productType: string = "All";
  getPartDetails(part) {
    let modal = this.modalCtrl.create(ShowDetails,part);
    modal.present();
  }
  searchPart(){
    let postData = {
          image: this.base64Image.split(',')[1],
          prodType: "test"
      }
    let headers = new Headers({ 'Content-Type': 'application/json' });
    return this.http.post(this.partsInfoURL, postData, {headers: headers} ).map(res => res.json())
    .subscribe(data => {
      console.log(data);
      this.partData=data;
   });
  }
}

import { Component } from '@angular/core';
import { Camera } from 'ionic-native';
import { Http, Headers } from '@angular/http';
import { ModalController,NavParams,LoadingController } from 'ionic-angular';
import { ShowDetails } from './showDetails';
import { Geolocation } from '@ionic-native/geolocation';
import 'rxjs/add/operator/map';
@Component({
  templateUrl: 'home.html'
})

export class HomePage {
  public base64Image: string;
  public partDet: any;
  partData: any;
  lat: number;
  longt: number;
  isNoResult: boolean;
  enableSearch:boolean;
  enableClear:boolean;
  private partsInfoURL='http://10.x.xxx.xxx:8080/partsearch/uploadImage';
  constructor(public http: Http, public modalCtrl: ModalController,public params: NavParams, private geolocation: Geolocation,public loadingController:LoadingController) {
  }

  takePicture(){
    Camera.getPicture({
        quality : 100,
        destinationType : Camera.DestinationType.DATA_URL,
        sourceType : Camera.PictureSourceType.CAMERA,
        allowEdit : true,
        encodingType: Camera.EncodingType.JPEG,
        saveToPhotoAlbum: false
    }).then((imageData) => {
        this.base64Image = "data:image/jpeg;base64," + imageData;
        this.enableSearch=true;
        this.enableClear=true;
        this.partData="";
    }, (err) => {
        console.log(err);
    });
  }
  SelectPicture(){
    Camera.getPicture({
        quality : 75,
        destinationType : Camera.DestinationType.DATA_URL,
        sourceType : Camera.PictureSourceType.PHOTOLIBRARY,
        allowEdit : true,
        encodingType: Camera.EncodingType.JPEG,
        targetWidth: 224,
        targetHeight: 224,
        saveToPhotoAlbum: false
    }).then((imageData) => {
        this.base64Image = "data:image/jpeg;base64," + imageData;
        this.enableSearch=true;
        this.enableClear=true;
        this.partData="";
    }, (err) => {
        console.log(err);
    });
  }
  productTypes(): string[] {
    return [
      "Filters",
      "Batteries",
      "Bearings"
    ];
  }
  productType: string = "All";
  getPartDetails(part) {
  let partAvailDetails={
     "partAvailDetails":{
       "partNum": part.curPart.partNum,
       "lineAbbrev": part.curPart.lineAbbrev,
       "imageName": part.curPart.imageName,
       "lat":this.lat,
       "longt":this.longt
     }
   }
     let modal = this.modalCtrl.create(ShowDetails,partAvailDetails);
     modal.present();
   }
   clearPicture(){
     this.base64Image="";
     this.partData="";
   }
  searchPart(){
    this.geolocation.getCurrentPosition().then((data) => {
            this.lat=data.coords.latitude;
            this.longt=data.coords.longitude;
        });
    let postData = {
          image: this.base64Image.split(',')[1],
          prodType: "test"
      }
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let loading = this.loadingController.create({content : "Searching for parts...please wait"});
    loading.present();
    return this.http.post(this.partsInfoURL, postData, {headers: headers} ).map(res => res.json())
    .subscribe(data => {
      console.log(data);
      this.partData=data;
      this.enableSearch=false;
      this.enableClear=false;
    loading.dismissAll();
   });
  }
}
